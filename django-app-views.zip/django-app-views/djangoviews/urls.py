from django.urls import path
from .views import ReporterFormView, ArticleCreate, DefaultTemplateView, \
                    ArticleListView, ArticleUpdateView, ArticleDeleteView

urlpatterns = [
    path('default_TemplateView/', DefaultTemplateView.as_view(), name='default_TemplateView'),
    path('reporter_formView/', ReporterFormView.as_view(), name='reporter_formView'),
    path('article_createView/', ArticleCreate.as_view(), name='article_createView'),
    path('article_listView/', ArticleListView.as_view(), name='article_listView'),
    path('article_updateView/<int:pk>', ArticleUpdateView.as_view(), name='article_updateView'),
    path('article_deleteView/<int:pk>', ArticleDeleteView.as_view(), name='article_deleteView'),
]