from django.apps import AppConfig


class DjangoviewsConfig(AppConfig):
    name = 'djangoviews'
