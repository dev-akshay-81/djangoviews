from django.shortcuts import render
from django.urls import reverse_lazy
from .forms import ReporterForm
from django.views.generic import TemplateView, ListView
from django.views.generic.edit import FormView, CreateView, UpdateView, DeleteView
from .models import Reporter, Article



class DefaultTemplateView(TemplateView):
    template_name = "default.html"

class ReporterFormView(FormView):
    template_name = 'reporter_form.html'
    form_class = ReporterForm
    success_url = '/default/dashboard/'

    def form_valid(self, form):
        # This method is called when valid form data has been POSTed.
        # It should return an HttpResponse.

        full_name = form.cleaned_data['full_name']
        reporterObj = Reporter(full_name=full_name)
        reporterObj.save()

        return super().form_valid(form)


class ArticleCreate(CreateView):
    template_name = 'article_form.html'
    model = Article
    fields = ['headline', 'content', 'reporter', 'pub_date']
    success_url = reverse_lazy('article_listView')

    def form_valid(self, form):

        print("form_valid executed for 'ArticleCreate' ")

        return super().form_valid(form)


class ArticleListView(ListView):
    template_name = 'article_list.html'
    model = Article


class ArticleUpdateView(UpdateView):
    template_name = 'article_form.html'
    model = Article
    fields = ['headline', 'content', 'reporter', 'pub_date']
    success_url = reverse_lazy('article_listView')


class ArticleDeleteView(DeleteView):
    template_name = 'article_delete.html'
    model = Article
    success_url = reverse_lazy('article_listView')