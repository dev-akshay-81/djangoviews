from django import forms

class ReporterForm(forms.Form):
    full_name = forms.CharField()