from django.urls import path
from django.contrib.auth import views as auth_views
from . import views

urlpatterns = [
    #path('forgot-password/', views.forgotPassword, name='forgot_password'),
    path('register-user/', views.registerUser, name='register_user'),
    #path('', views.login, name='login'),
    path('', auth_views.LoginView.as_view(template_name = 'security_login.html'),  name='login'),
]